<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>

<h2>Welcome, Admin!</h2>
<a href="logout.php">Logout</a>
<ul>
    <li><a href="pages/dashboard.php">Dashboard</a></li>
    <li><a href="pages/brands.php">Brands</a></li>
    <li><a href="pages/category.php">Category</a></li>
    <li><a href="pages/product.php">Products</a></li>
</ul>
