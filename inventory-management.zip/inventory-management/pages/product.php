<?php
include '../includes/db_connect.php';

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<h2>Product List</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Brand</th>
        <th>Category</th>
        <th>Stock</th>
        <th>Price</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['brand']; ?></td>
        <td><?php echo $row['category']; ?></td>
        <td><?php echo $row['stock']; ?></td>
        <td><?php echo $row['price']; ?></td>
    </tr>
    <?php } ?>
</table>
